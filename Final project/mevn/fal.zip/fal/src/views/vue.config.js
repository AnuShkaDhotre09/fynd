module.exports={
    devServe:{
        proxy:'http//localhost:8000',
    },
}