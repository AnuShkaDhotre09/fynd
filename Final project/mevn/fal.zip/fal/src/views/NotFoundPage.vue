<template>
    <h1>404:Page Not Found</h1>
</template>

<script>
export default {
    name:'NotFoundPage',

};
</script>

<style scoped>
h1{
    text-align: center;
}
</style>